void PrintArray (int arr[][10], std::ostream& out);
void CreateB (int arr1[][10], int arr2[][10]);
void CreateC (int arr1[][10], int arr2[][10]);
void CreateD (int arr1[][10], int arr2[][10], int arr3[][10]);
void AddArray (int arr1[][10], int arr2[][10]);
